@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$pidFile = Join-Path '%~dp0' 'desktop-pet.pid'; if (Test-Path -LiteralPath $pidFile) { $petPid = [int](Get-Content -LiteralPath $pidFile -Raw); Stop-Process -Id $petPid -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue }"
