Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:RootDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ConfigPath = Join-Path $script:RootDir "desktop-pet.config.json"
$script:PidPath = Join-Path $script:RootDir "desktop-pet.pid"
$script:TasksDir = Join-Path $script:RootDir "tasks"
$script:DefaultImagePath = Join-Path $script:RootDir "default\default.png"
$script:Random = [System.Random]::new()
$script:ReminderWindow = $null
$script:RemindedTasks = @{}
$script:DdlReminderMinutes = 10
$script:Config = [ordered]@{
  imagePath = $script:DefaultImagePath
  name = "Mimo"
  size = 150
  x = 0
  y = 0
  wander = $false
}

function Import-PetConfig {
  if (-not (Test-Path -LiteralPath $script:ConfigPath)) {
    return
  }

  try {
    $saved = Get-Content -LiteralPath $script:ConfigPath -Raw | ConvertFrom-Json
    foreach ($key in @("imagePath", "name", "size", "x", "y", "wander")) {
      if ($null -ne $saved.$key) {
        $script:Config[$key] = $saved.$key
      }
    }
  } catch {
    $script:Config["imagePath"] = $script:DefaultImagePath
    $script:Config["name"] = "Mimo"
  }

  if (-not [string]$script:Config["name"]) {
    $script:Config["name"] = "Mimo"
  }

  if (-not [string]$script:Config["imagePath"] -or -not (Test-Path -LiteralPath ([string]$script:Config["imagePath"]))) {
    $script:Config["imagePath"] = $script:DefaultImagePath
  }
}

function Save-PetConfig {
  $script:Config | ConvertTo-Json | Set-Content -LiteralPath $script:ConfigPath -Encoding UTF8
}

function Save-PetPid {
  [string]$PID | Set-Content -LiteralPath $script:PidPath -Encoding ASCII
}

function Ensure-TasksDir {
  if (-not (Test-Path -LiteralPath $script:TasksDir)) {
    New-Item -ItemType Directory -Path $script:TasksDir | Out-Null
  }
}

function Clamp-Number($value, $min, $max) {
  return [Math]::Min([Math]::Max([double]$value, [double]$min), [double]$max)
}

function Set-PetSize($size) {
  $next = [int](Clamp-Number $size 72 280)
  $script:Config["size"] = $next
  $script:Window.Width = $next
  $script:Window.Height = $next + 28
  $script:Avatar.Width = $next
  $script:Avatar.Height = $next
  Save-PetConfig
}

function Set-PetImage($path) {
  if (-not $path -or -not (Test-Path -LiteralPath $path)) {
    $script:Avatar.Source = $null
    $script:Hint.Visibility = "Visible"
    return
  }

  $bitmap = [System.Windows.Media.Imaging.BitmapImage]::new()
  $bitmap.BeginInit()
  $bitmap.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
  $bitmap.UriSource = [Uri]::new($path)
  $bitmap.EndInit()
  $bitmap.Freeze()

  $script:Avatar.Source = $bitmap
  $script:Hint.Visibility = "Collapsed"
}

function Select-PetImage {
  $dialog = [System.Windows.Forms.OpenFileDialog]::new()
  $dialog.Title = "Choose a pet photo"
  $dialog.Filter = "Image files|*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif|All files|*.*"
  $dialog.Multiselect = $false

  if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    $script:Config["imagePath"] = $dialog.FileName
    Set-PetImage $dialog.FileName
    Save-PetConfig
  }
}

function Rename-Pet {
  $form = [System.Windows.Forms.Form]::new()
  $form.Text = "Rename pet"
  $form.Width = 300
  $form.Height = 135
  $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
  $form.MaximizeBox = $false
  $form.MinimizeBox = $false
  $form.TopMost = $true

  $input = [System.Windows.Forms.TextBox]::new()
  $input.Left = 14
  $input.Top = 16
  $input.Width = 256
  $input.Text = [string]$script:Config["name"]

  $ok = [System.Windows.Forms.Button]::new()
  $ok.Text = "OK"
  $ok.Left = 114
  $ok.Top = 52
  $ok.Width = 74
  $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK

  $cancel = [System.Windows.Forms.Button]::new()
  $cancel.Text = "Cancel"
  $cancel.Left = 196
  $cancel.Top = 52
  $cancel.Width = 74
  $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

  $form.AcceptButton = $ok
  $form.CancelButton = $cancel
  $form.Controls.Add($input) | Out-Null
  $form.Controls.Add($ok) | Out-Null
  $form.Controls.Add($cancel) | Out-Null

  if ($form.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    $nextName = $input.Text.Trim()
    if (-not $nextName) {
      $nextName = "Pet"
    }

    $script:Config["name"] = $nextName
    $script:NameLabel.Text = $nextName
    Save-PetConfig
  }

  $form.Dispose()
}

function Add-DefaultTaskRows($grid) {
  $grid.Rows.Add($false, "Must do", "", "") | Out-Null
  $grid.Rows.Add($false, "Must do", "", "") | Out-Null
  $grid.Rows.Add($false, "Must do", "", "") | Out-Null
  $grid.Rows.Add($false, "Study / Work", "", "") | Out-Null
  $grid.Rows.Add($false, "Study / Work", "", "") | Out-Null
  $grid.Rows.Add($false, "Life", "", "") | Out-Null
  $grid.Rows.Add($false, "Life", "", "") | Out-Null
}

function Set-TaskGridZoom($grid, [double]$size) {
  $fontSize = Clamp-Number $size 9 18
  $grid.Font = [System.Drawing.Font]::new("Segoe UI", $fontSize)
  $grid.ColumnHeadersDefaultCellStyle.Font = [System.Drawing.Font]::new("Segoe UI Semibold", $fontSize)
  $grid.ColumnHeadersHeight = [int]($fontSize * 3.2)
  $grid.RowTemplate.Height = [int]($fontSize * 2.6)
  foreach ($row in $grid.Rows) {
    $row.Height = $grid.RowTemplate.Height
  }
}

function Get-CurrentMinuteDateTime {
  $now = Get-Date
  return [DateTime]::new($now.Year, $now.Month, $now.Day, $now.Hour, $now.Minute, 0)
}

function Show-DdlPicker($grid, [int]$rowIndex) {
  if ($rowIndex -lt 0) {
    return
  }

  $currentText = [string]$grid.Rows[$rowIndex].Cells["ddl"].Value
  $selectedTime = Get-CurrentMinuteDateTime
  $parsedTime = [DateTime]::MinValue
  if ($currentText -and [DateTime]::TryParse($currentText, [ref]$parsedTime)) {
    $selectedTime = [DateTime]::new($parsedTime.Year, $parsedTime.Month, $parsedTime.Day, $parsedTime.Hour, $parsedTime.Minute, 0)
  }

  $popup = [System.Windows.Forms.Form]::new()
  $popup.Text = "Choose DDL"
  $popup.Width = 310
  $popup.Height = 138
  $popup.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedToolWindow
  $popup.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
  $popup.TopMost = $true
  $popup.BackColor = [System.Drawing.Color]::FromArgb(255, 248, 240)
  $popup.Font = [System.Drawing.Font]::new("Segoe UI", 10)

  $cellRect = $grid.GetCellDisplayRectangle($grid.Columns["ddl"].Index, $rowIndex, $true)
  $screenPoint = $grid.PointToScreen([System.Drawing.Point]::new($cellRect.Left, $cellRect.Bottom + 4))
  $popup.Left = $screenPoint.X
  $popup.Top = $screenPoint.Y

  $picker = [System.Windows.Forms.DateTimePicker]::new()
  $picker.Left = 14
  $picker.Top = 16
  $picker.Width = 266
  $picker.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
  $picker.CustomFormat = "yyyy-MM-dd HH:mm"
  $picker.Value = $selectedTime

  $use = [System.Windows.Forms.Button]::new()
  $use.Text = "Use"
  $use.Left = 64
  $use.Top = 58
  $use.Width = 64
  $use.Height = 28
  $use.Add_Click({
    $value = $picker.Value
    $grid.Rows[$rowIndex].Cells["ddl"].Value = $value.ToString("yyyy-MM-dd HH:mm")
    $popup.Close()
  })

  $clear = [System.Windows.Forms.Button]::new()
  $clear.Text = "Clear"
  $clear.Left = 136
  $clear.Top = 58
  $clear.Width = 64
  $clear.Height = 28
  $clear.Add_Click({
    $grid.Rows[$rowIndex].Cells["ddl"].Value = ""
    $popup.Close()
  })

  $cancel = [System.Windows.Forms.Button]::new()
  $cancel.Text = "Cancel"
  $cancel.Left = 208
  $cancel.Top = 58
  $cancel.Width = 72
  $cancel.Height = 28
  $cancel.Add_Click({
    $popup.Close()
  })

  $popup.Controls.Add($picker) | Out-Null
  $popup.Controls.Add($use) | Out-Null
  $popup.Controls.Add($clear) | Out-Null
  $popup.Controls.Add($cancel) | Out-Null
  $popup.ShowDialog() | Out-Null
  $popup.Dispose()
}

function Get-TaskReminderKey($filePath, $index, $ddl, $taskText) {
  return "$filePath|$index|$ddl|$taskText"
}

function Show-TaskReminder($taskText, $category, $ddl, $minutesLeft) {
  if ($script:ReminderWindow) {
    $script:ReminderWindow.Close()
    $script:ReminderWindow = $null
  }

  $form = [System.Windows.Forms.Form]::new()
  $form.Text = "DDL Reminder"
  $form.Width = 420
  $form.Height = 210
  $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
  $form.TopMost = $true
  $form.BackColor = [System.Drawing.Color]::FromArgb(255, 248, 240)
  $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedToolWindow
  $form.Font = [System.Drawing.Font]::new("Segoe UI", 10)

  $title = [System.Windows.Forms.Label]::new()
  $title.Text = "DDL is almost here"
  if ($minutesLeft -le 0) {
    $title.Text = "DDL is due now"
  }
  $title.Left = 20
  $title.Top = 18
  $title.Width = 360
  $title.Height = 28
  $title.Font = [System.Drawing.Font]::new("Segoe UI Semibold", 13)
  $title.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)

  $timeText = "Due: $ddl"
  if ($minutesLeft -gt 0) {
    $timeText = "Due in $minutesLeft minute(s): $ddl"
  }
  $time = [System.Windows.Forms.Label]::new()
  $time.Text = $timeText
  $time.Left = 20
  $time.Top = 54
  $time.Width = 370
  $time.Height = 24
  $time.ForeColor = [System.Drawing.Color]::FromArgb(137, 93, 76)

  $task = [System.Windows.Forms.Label]::new()
  $task.Text = "[$category] $taskText"
  $task.Left = 20
  $task.Top = 86
  $task.Width = 370
  $task.Height = 44
  $task.ForeColor = [System.Drawing.Color]::FromArgb(55, 47, 43)

  $open = [System.Windows.Forms.Button]::new()
  $open.Text = "Open tasks"
  $open.Left = 190
  $open.Top = 136
  $open.Width = 96
  $open.Height = 32
  $open.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $open.FlatAppearance.BorderSize = 0
  $open.BackColor = [System.Drawing.Color]::FromArgb(129, 176, 151)
  $open.ForeColor = [System.Drawing.Color]::White
  $open.Add_Click({
    $form.Close()
    Open-TodayTaskTemplate
  })

  $ok = [System.Windows.Forms.Button]::new()
  $ok.Text = "OK"
  $ok.Left = 298
  $ok.Top = 136
  $ok.Width = 76
  $ok.Height = 32
  $ok.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $ok.FlatAppearance.BorderSize = 0
  $ok.BackColor = [System.Drawing.Color]::FromArgb(238, 217, 202)
  $ok.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $ok.Add_Click({
    $form.Close()
  })

  $form.Controls.Add($title) | Out-Null
  $form.Controls.Add($time) | Out-Null
  $form.Controls.Add($task) | Out-Null
  $form.Controls.Add($open) | Out-Null
  $form.Controls.Add($ok) | Out-Null
  $form.Add_FormClosed({
    $script:ReminderWindow = $null
  })

  $script:ReminderWindow = $form
  $form.Show()
}

function Check-DdlReminders {
  Ensure-TasksDir
  $now = Get-CurrentMinuteDateTime
  $files = Get-ChildItem -LiteralPath $script:TasksDir -Filter "*.json" -File -ErrorAction SilentlyContinue

  foreach ($file in $files) {
    try {
      $rows = @(Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json)
    } catch {
      continue
    }

    $index = 0
    foreach ($item in $rows) {
      $index++
      if ([bool]$item.done) {
        continue
      }

      $taskText = [string]$item.task
      $ddlText = [string]$item.ddl
      if (-not $taskText.Trim() -or -not $ddlText.Trim()) {
        continue
      }

      $ddlTime = [DateTime]::MinValue
      if (-not [DateTime]::TryParse($ddlText, [ref]$ddlTime)) {
        continue
      }
      $ddlTime = [DateTime]::new($ddlTime.Year, $ddlTime.Month, $ddlTime.Day, $ddlTime.Hour, $ddlTime.Minute, 0)
      $minutesLeft = [int][Math]::Ceiling(($ddlTime - $now).TotalMinutes)
      if ($minutesLeft -gt $script:DdlReminderMinutes -or $minutesLeft -lt -1440) {
        continue
      }

      $key = Get-TaskReminderKey $file.FullName $index $ddlTime.ToString("yyyy-MM-dd HH:mm") $taskText
      if ($script:RemindedTasks.ContainsKey($key)) {
        continue
      }

      $script:RemindedTasks[$key] = $true
      Show-TaskReminder $taskText ([string]$item.category) ($ddlTime.ToString("yyyy-MM-dd HH:mm")) $minutesLeft
      return
    }
  }
}

function Open-TodayTaskTemplate {
  Ensure-TasksDir
  $dateText = Get-Date -Format "yyyy-MM-dd"
  $taskPath = Join-Path $script:TasksDir "$dateText.json"

  $form = [System.Windows.Forms.Form]::new()
  $form.Text = "Pet Task Board"
  $form.Width = 820
  $form.Height = 700
  $form.MinimumSize = [System.Drawing.Size]::new(760, 560)
  $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
  $form.TopMost = $true
  $form.MinimizeBox = $true
  $form.BackColor = [System.Drawing.Color]::FromArgb(255, 248, 240)
  $form.Font = [System.Drawing.Font]::new("Segoe UI", 10)
  $form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None

  $header = [System.Windows.Forms.Panel]::new()
  $header.Left = 0
  $header.Top = 0
  $header.Width = 820
  $header.Height = 116
  $header.Anchor = "Top, Left, Right"
  $header.BackColor = [System.Drawing.Color]::FromArgb(255, 235, 219)

  $title = [System.Windows.Forms.Label]::new()
  $title.Text = "Today's task table"
  $title.Left = 42
  $title.Top = 16
  $title.Width = 470
  $title.Height = 48
  $title.Font = [System.Drawing.Font]::new("Segoe UI Semibold", 16)
  $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $title.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $title.BackColor = [System.Drawing.Color]::Transparent

  $dateLabel = [System.Windows.Forms.Label]::new()
  $dateLabel.Text = "Date: $dateText"
  $dateLabel.Left = 44
  $dateLabel.Top = 70
  $dateLabel.Width = 220
  $dateLabel.Height = 28
  $dateLabel.ForeColor = [System.Drawing.Color]::FromArgb(137, 93, 76)
  $dateLabel.BackColor = [System.Drawing.Color]::Transparent

  $hint = [System.Windows.Forms.Label]::new()
  $hint.Text = "Resize the window. The table follows."
  $hint.Left = 420
  $hint.Top = 72
  $hint.Width = 360
  $hint.Height = 22
  $hint.Anchor = "Top, Right"
  $hint.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
  $hint.ForeColor = [System.Drawing.Color]::FromArgb(137, 93, 76)
  $hint.BackColor = [System.Drawing.Color]::Transparent

  $pathLabel = [System.Windows.Forms.Label]::new()
  $pathLabel.Text = $taskPath
  $pathLabel.Left = 44
  $pathLabel.Top = 134
  $pathLabel.Width = 760
  $pathLabel.Height = 24
  $pathLabel.Anchor = "Top, Left, Right"
  $pathLabel.ForeColor = [System.Drawing.Color]::FromArgb(144, 122, 111)
  $pathLabel.Font = [System.Drawing.Font]::new("Segoe UI", 8.5)

  $grid = [System.Windows.Forms.DataGridView]::new()
  $grid.Left = 44
  $grid.Top = 174
  $grid.Width = 760
  $grid.Height = 420
  $grid.Anchor = "Top, Bottom, Left, Right"
  $grid.BackgroundColor = [System.Drawing.Color]::White
  $grid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
  $grid.GridColor = [System.Drawing.Color]::FromArgb(238, 217, 202)
  $grid.RowHeadersVisible = $false
  $grid.AllowUserToAddRows = $true
  $grid.AllowUserToDeleteRows = $true
  $grid.AutoSizeRowsMode = [System.Windows.Forms.DataGridViewAutoSizeRowsMode]::None
  $grid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::CellSelect
  $grid.MultiSelect = $false
  $grid.EnableHeadersVisualStyles = $false
  $grid.ColumnHeadersHeightSizeMode = [System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode]::DisableResizing
  $grid.ColumnHeadersHeight = 36
  $grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255, 235, 219)
  $grid.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $grid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(255, 242, 230)
  $grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::FromArgb(55, 47, 43)

  $doneCol = [System.Windows.Forms.DataGridViewCheckBoxColumn]::new()
  $doneCol.Name = "done"
  $doneCol.HeaderText = "Done"
  $doneCol.Width = 76
  $grid.Columns.Add($doneCol) | Out-Null

  $categoryCol = [System.Windows.Forms.DataGridViewComboBoxColumn]::new()
  $categoryCol.Name = "category"
  $categoryCol.HeaderText = "Category"
  $categoryCol.Width = 220
  $categoryCol.Items.AddRange([object[]]@("Must do", "Study / Work", "Life", "Notes"))
  $grid.Columns.Add($categoryCol) | Out-Null

  $taskCol = [System.Windows.Forms.DataGridViewTextBoxColumn]::new()
  $taskCol.Name = "task"
  $taskCol.HeaderText = "Task"
  $taskCol.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
  $grid.Columns.Add($taskCol) | Out-Null

  $ddlCol = [System.Windows.Forms.DataGridViewTextBoxColumn]::new()
  $ddlCol.Name = "ddl"
  $ddlCol.HeaderText = "DDL"
  $ddlCol.Width = 150
  $ddlCol.ReadOnly = $true
  $grid.Columns.Add($ddlCol) | Out-Null

  if (Test-Path -LiteralPath $taskPath) {
    try {
      $rows = Get-Content -LiteralPath $taskPath -Raw | ConvertFrom-Json
      foreach ($item in $rows) {
        $grid.Rows.Add([bool]$item.done, [string]$item.category, [string]$item.task, [string]$item.ddl) | Out-Null
      }
    } catch {
      Add-DefaultTaskRows $grid
    }
  } else {
    Add-DefaultTaskRows $grid
  }

  $script:TaskGridZoom = 10.5
  Set-TaskGridZoom $grid $script:TaskGridZoom
  $grid.Add_CellClick({
    param($sender, $eventArgs)
    if ($eventArgs.RowIndex -ge 0 -and $eventArgs.ColumnIndex -eq $grid.Columns["ddl"].Index) {
      Show-DdlPicker $grid $eventArgs.RowIndex
    }
  })

  $status = [System.Windows.Forms.Label]::new()
  $status.Text = "Ready"
  $status.Left = 44
  $status.Top = 606
  $status.Width = 250
  $status.Height = 28
  $status.Anchor = "Bottom, Left"
  $status.ForeColor = [System.Drawing.Color]::FromArgb(137, 93, 76)

  $zoomOut = [System.Windows.Forms.Button]::new()
  $zoomOut.Text = "A-"
  $zoomOut.Left = 360
  $zoomOut.Top = 602
  $zoomOut.Width = 64
  $zoomOut.Height = 34
  $zoomOut.Anchor = "Bottom, Right"
  $zoomOut.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $zoomOut.FlatAppearance.BorderSize = 0
  $zoomOut.BackColor = [System.Drawing.Color]::FromArgb(255, 235, 219)
  $zoomOut.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $zoomOut.Add_Click({
    $script:TaskGridZoom = $script:TaskGridZoom - 1
    Set-TaskGridZoom $grid $script:TaskGridZoom
  })

  $zoomIn = [System.Windows.Forms.Button]::new()
  $zoomIn.Text = "A+"
  $zoomIn.Left = 444
  $zoomIn.Top = 602
  $zoomIn.Width = 64
  $zoomIn.Height = 34
  $zoomIn.Anchor = "Bottom, Right"
  $zoomIn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $zoomIn.FlatAppearance.BorderSize = 0
  $zoomIn.BackColor = [System.Drawing.Color]::FromArgb(255, 235, 219)
  $zoomIn.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $zoomIn.Add_Click({
    $script:TaskGridZoom = $script:TaskGridZoom + 1
    Set-TaskGridZoom $grid $script:TaskGridZoom
  })

  $newTemplate = [System.Windows.Forms.Button]::new()
  $newTemplate.Text = "New table"
  $newTemplate.Left = 528
  $newTemplate.Top = 602
  $newTemplate.Width = 112
  $newTemplate.Height = 34
  $newTemplate.Anchor = "Bottom, Right"
  $newTemplate.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $newTemplate.FlatAppearance.BorderSize = 0
  $newTemplate.BackColor = [System.Drawing.Color]::FromArgb(255, 235, 219)
  $newTemplate.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $newTemplate.Add_Click({
    $grid.Rows.Clear()
    Add-DefaultTaskRows $grid
    Set-TaskGridZoom $grid $script:TaskGridZoom
    $status.Text = "A fresh table is ready."
  })

  $save = [System.Windows.Forms.Button]::new()
  $save.Text = "Save"
  $save.Left = 640
  $save.Top = 602
  $save.Width = 68
  $save.Height = 34
  $save.Anchor = "Bottom, Right"
  $save.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $save.FlatAppearance.BorderSize = 0
  $save.BackColor = [System.Drawing.Color]::FromArgb(129, 176, 151)
  $save.ForeColor = [System.Drawing.Color]::White
  $save.Add_Click({
    Ensure-TasksDir
    $data = @()
    foreach ($row in $grid.Rows) {
      if ($row.IsNewRow) {
        continue
      }
      $taskText = [string]$row.Cells["task"].Value
      $category = [string]$row.Cells["category"].Value
      $ddl = [string]$row.Cells["ddl"].Value
      $done = $false
      if ($null -ne $row.Cells["done"].Value) {
        $done = [bool]$row.Cells["done"].Value
      }
      if ($taskText.Trim() -or $done) {
        if (-not $category) {
          $category = "Must do"
        }
        $data += [pscustomobject]@{
          done = $done
          category = $category
          ddl = $ddl
          task = $taskText
        }
      }
    }
    $data | ConvertTo-Json | Set-Content -LiteralPath $taskPath -Encoding UTF8
    $status.Text = "Saved table."
  })

  $close = [System.Windows.Forms.Button]::new()
  $close.Text = "Close"
  $close.Left = 716
  $close.Top = 602
  $close.Width = 68
  $close.Height = 34
  $close.Anchor = "Bottom, Right"
  $close.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $close.FlatAppearance.BorderSize = 0
  $close.BackColor = [System.Drawing.Color]::FromArgb(238, 217, 202)
  $close.ForeColor = [System.Drawing.Color]::FromArgb(93, 59, 49)
  $close.Add_Click({
    $form.Close()
  })

  $layoutTaskBoard = {
    $header.Width = $form.ClientSize.Width
    $hint.Left = [Math]::Max(280, $form.ClientSize.Width - $hint.Width - 24)
    $pathLabel.Width = $form.ClientSize.Width - 88
    $grid.Width = $form.ClientSize.Width - 88
    $grid.Height = [Math]::Max(220, $form.ClientSize.Height - 260)

    $buttonTop = $form.ClientSize.Height - 48
    $status.Top = $buttonTop + 4
    $zoomOut.Top = $buttonTop
    $zoomIn.Top = $buttonTop
    $newTemplate.Top = $buttonTop
    $save.Top = $buttonTop
    $close.Top = $buttonTop

    $close.Left = $form.ClientSize.Width - $close.Width - 24
    $save.Left = $close.Left - $save.Width - 8
    $newTemplate.Left = $save.Left - $newTemplate.Width - 8
    $zoomIn.Left = $newTemplate.Left - $zoomIn.Width - 8
    $zoomOut.Left = $zoomIn.Left - $zoomOut.Width - 8
    $status.Width = [Math]::Max(160, $zoomOut.Left - 48)
  }
  $form.Add_Shown($layoutTaskBoard)
  $form.Add_Resize($layoutTaskBoard)

  $header.Controls.Add($title) | Out-Null
  $header.Controls.Add($dateLabel) | Out-Null
  $header.Controls.Add($hint) | Out-Null
  $form.Controls.Add($header) | Out-Null
  $form.Controls.Add($pathLabel) | Out-Null
  $form.Controls.Add($grid) | Out-Null
  $form.Controls.Add($status) | Out-Null
  $form.Controls.Add($zoomOut) | Out-Null
  $form.Controls.Add($zoomIn) | Out-Null
  $form.Controls.Add($newTemplate) | Out-Null
  $form.Controls.Add($save) | Out-Null
  $form.Controls.Add($close) | Out-Null
  $form.ShowDialog() | Out-Null
  $form.Dispose()
}

function Move-Pet($x, $y, [bool]$animate) {
  $workArea = [System.Windows.SystemParameters]::WorkArea
  $maxX = $workArea.Right - $script:Window.Width
  $maxY = $workArea.Bottom - $script:Window.Height
  $nextX = Clamp-Number $x $workArea.Left $maxX
  $nextY = Clamp-Number $y $workArea.Top $maxY

  if ($animate) {
    $duration = [System.Windows.Duration]::new([TimeSpan]::FromMilliseconds(850))
    $leftAnimation = [System.Windows.Media.Animation.DoubleAnimation]::new($script:Window.Left, $nextX, $duration)
    $topAnimation = [System.Windows.Media.Animation.DoubleAnimation]::new($script:Window.Top, $nextY, $duration)
    $leftAnimation.EasingFunction = [System.Windows.Media.Animation.SineEase]::new()
    $topAnimation.EasingFunction = [System.Windows.Media.Animation.SineEase]::new()
    $script:Window.BeginAnimation([System.Windows.Window]::LeftProperty, $leftAnimation)
    $script:Window.BeginAnimation([System.Windows.Window]::TopProperty, $topAnimation)
  } else {
    $script:Window.BeginAnimation([System.Windows.Window]::LeftProperty, $null)
    $script:Window.BeginAnimation([System.Windows.Window]::TopProperty, $null)
    $script:Window.Left = $nextX
    $script:Window.Top = $nextY
  }
}

function Close-Pet {
  Save-PetConfig
  if ($script:TrayIcon) {
    $script:TrayIcon.Visible = $false
    $script:TrayIcon.Dispose()
    $script:TrayIcon = $null
  }
  if ($script:PetMenuWindow) {
    $script:PetMenuWindow.Close()
    $script:PetMenuWindow = $null
  }
  if ($script:PetContextMenu) {
    $script:PetContextMenu.Dispose()
    $script:PetContextMenu = $null
  }
  if ($script:ReminderWindow) {
    $script:ReminderWindow.Close()
    $script:ReminderWindow = $null
  }
  if (Test-Path -LiteralPath $script:PidPath) {
    Remove-Item -LiteralPath $script:PidPath -Force
  }
  $script:Window.Close()
}

Import-PetConfig
Save-PetPid

$script:Window = [System.Windows.Window]::new()
$script:Window.Title = "Desktop Pet"
$script:Window.WindowStyle = "None"
$script:Window.AllowsTransparency = $true
$script:Window.Background = [System.Windows.Media.Brushes]::Transparent
$script:Window.Topmost = $true
$script:Window.ShowInTaskbar = $false
$script:Window.ResizeMode = "NoResize"

$root = [System.Windows.Controls.Grid]::new()
$root.Background = [System.Windows.Media.Brushes]::Transparent
$script:Avatar = [System.Windows.Controls.Image]::new()
$script:Avatar.Stretch = [System.Windows.Media.Stretch]::Uniform
$script:Avatar.Effect = [System.Windows.Media.Effects.DropShadowEffect]@{
  BlurRadius = 18
  ShadowDepth = 6
  Opacity = 0.28
}

$script:Hint = [System.Windows.Controls.TextBlock]::new()
$script:Hint.Text = "Right-click to choose photo"
$script:Hint.HorizontalAlignment = "Center"
$script:Hint.VerticalAlignment = "Center"
$script:Hint.Foreground = [System.Windows.Media.Brushes]::DarkSlateGray
$script:Hint.FontSize = 13
$script:Hint.IsHitTestVisible = $false

$nameBar = [System.Windows.Controls.StackPanel]::new()
$nameBar.Orientation = "Horizontal"
$nameBar.HorizontalAlignment = "Center"
$nameBar.VerticalAlignment = "Bottom"
$nameBar.Background = [System.Windows.Media.Brushes]::Transparent

$script:NameLabel = [System.Windows.Controls.TextBlock]::new()
$script:NameLabel.Text = [string]$script:Config["name"]
$script:NameLabel.Margin = [System.Windows.Thickness]::new(0, 0, 4, 0)
$script:NameLabel.Padding = [System.Windows.Thickness]::new(8, 4, 8, 4)
$script:NameLabel.Foreground = [System.Windows.Media.Brushes]::Black
$script:NameLabel.Background = [System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.Color]::FromArgb(230, 255, 255, 255))
$script:NameLabel.FontFamily = [System.Windows.Media.FontFamily]::new("Microsoft YaHei")
$script:NameLabel.FontSize = 12

$nameBar.Children.Add($script:NameLabel) | Out-Null

$root.Children.Add($script:Avatar) | Out-Null
$root.Children.Add($script:Hint) | Out-Null
$root.Children.Add($nameBar) | Out-Null
$script:Window.Content = $root

function Add-PetMenuButton($panel, $text, $action) {
  $button = [System.Windows.Controls.Button]::new()
  $button.Content = $text
  $button.HorizontalContentAlignment = "Left"
  $button.MinWidth = 190
  $button.Margin = [System.Windows.Thickness]::new(0, 3, 0, 3)
  $button.Padding = [System.Windows.Thickness]::new(12, 8, 12, 8)
  $button.BorderThickness = [System.Windows.Thickness]::new(0)
  $button.Foreground = [System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.Color]::FromRgb(61, 47, 43))
  $button.Background = [System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.Color]::FromRgb(255, 245, 235))
  $button.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")
  $button.FontSize = 13
  $button.Add_Click($action)
  $panel.Children.Add($button) | Out-Null
}

function Add-PetTrayMenuItem($menu, $text, $action) {
  $item = [System.Windows.Forms.MenuItem]::new($text)
  $item.Add_Click($action)
  $menu.MenuItems.Add($item) | Out-Null
}

function Add-PetMenuSeparator($panel) {
  $line = [System.Windows.Controls.Border]::new()
  $line.Height = 1
  $line.Margin = [System.Windows.Thickness]::new(6, 6, 6, 6)
  $line.Background = [System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.Color]::FromRgb(232, 202, 178))
  $panel.Children.Add($line) | Out-Null
}

function Show-PetMenu {
  if ($script:PetContextMenu) {
    $script:PetContextMenu.Dispose()
    $script:PetContextMenu = $null
  }

  $menu = [System.Windows.Forms.ContextMenuStrip]::new()
  $menu.BackColor = [System.Drawing.Color]::FromArgb(255, 250, 244)
  $menu.ForeColor = [System.Drawing.Color]::FromArgb(61, 47, 43)
  $menu.Font = [System.Drawing.Font]::new("Segoe UI", 10)
  $menu.Padding = [System.Windows.Forms.Padding]::new(6)

  $title = [System.Windows.Forms.ToolStripLabel]::new("My Pet")
  $title.ForeColor = [System.Drawing.Color]::FromArgb(129, 73, 58)
  $title.Font = [System.Drawing.Font]::new("Segoe UI Semibold", 10)
  $menu.Items.Add($title) | Out-Null
  $menu.Items.Add([System.Windows.Forms.ToolStripSeparator]::new()) | Out-Null

  $pick = [System.Windows.Forms.ToolStripMenuItem]::new("Pick a cute photo")
  $pick.Add_Click({ Select-PetImage })
  $menu.Items.Add($pick) | Out-Null

  $rename = [System.Windows.Forms.ToolStripMenuItem]::new("Give me a new name")
  $rename.Add_Click({ Rename-Pet })
  $menu.Items.Add($rename) | Out-Null

  $menu.Items.Add([System.Windows.Forms.ToolStripSeparator]::new()) | Out-Null

  $task = [System.Windows.Forms.ToolStripMenuItem]::new("Create task")
  $task.Add_Click({ Open-TodayTaskTemplate })
  $menu.Items.Add($task) | Out-Null

  $smaller = [System.Windows.Forms.ToolStripMenuItem]::new("Make me smaller")
  $smaller.Add_Click({ Set-PetSize ([int]$script:Config["size"] - 16) })
  $menu.Items.Add($smaller) | Out-Null

  $walkText = "Little walk mode: off"
  if ([bool]$script:Config["wander"]) {
    $walkText = "Little walk mode: on"
  }
  $walk = [System.Windows.Forms.ToolStripMenuItem]::new($walkText)
  $walk.Add_Click({
    $script:Config["wander"] = -not [bool]$script:Config["wander"]
    Save-PetConfig
  })
  $menu.Items.Add($walk) | Out-Null

  $menu.Items.Add([System.Windows.Forms.ToolStripSeparator]::new()) | Out-Null

  $exit = [System.Windows.Forms.ToolStripMenuItem]::new("Say bye")
  $exit.Add_Click({
    Close-Pet
  })
  $menu.Items.Add($exit) | Out-Null

  $script:PetContextMenu = $menu
  $menu.Show([System.Windows.Forms.Cursor]::Position)
}

function Attach-PetMouseHandlers($element) {
  $element.add_PreviewMouseRightButtonDown({
    param($sender, $eventArgs)
    $eventArgs.Handled = $true
    Show-PetMenu
  })
  $element.add_PreviewMouseRightButtonUp({
    param($sender, $eventArgs)
    $eventArgs.Handled = $true
  })
  $element.add_PreviewMouseLeftButtonDown({
    param($sender, $eventArgs)
    if ($eventArgs.ClickCount -ge 2) {
      $eventArgs.Handled = $true
      Close-Pet
    }
  })
}

function Create-TrayIcon {
  $trayMenu = [System.Windows.Forms.ContextMenu]::new()
  Add-PetTrayMenuItem $trayMenu "Show menu" { Show-PetMenu }
  Add-PetTrayMenuItem $trayMenu "Create task" { Open-TodayTaskTemplate }
  Add-PetTrayMenuItem $trayMenu "Rename" { Rename-Pet }
  Add-PetTrayMenuItem $trayMenu "Exit" { Close-Pet }

  $script:TrayIcon = [System.Windows.Forms.NotifyIcon]::new()
  $script:TrayIcon.Text = "Desktop Pet"
  $script:TrayIcon.Icon = [System.Drawing.SystemIcons]::Information
  $script:TrayIcon.ContextMenu = $trayMenu
  $script:TrayIcon.Visible = $true
  $script:TrayIcon.Add_Click({
    Show-PetMenu
  })
}

$script:Window.Add_MouseLeftButtonDown({
  try {
    $script:Window.DragMove()
  } catch {}
})

$script:Window.Add_MouseLeftButtonUp({
  $script:Config["x"] = [int]$script:Window.Left
  $script:Config["y"] = [int]$script:Window.Top
  Save-PetConfig
})

$script:Window.add_PreviewMouseRightButtonDown({
  param($sender, $eventArgs)
  $eventArgs.Handled = $true
  Show-PetMenu
})

Attach-PetMouseHandlers $root
Attach-PetMouseHandlers $script:Avatar
Attach-PetMouseHandlers $script:Hint
Attach-PetMouseHandlers $script:NameLabel
Attach-PetMouseHandlers $nameBar

$timer = [System.Windows.Threading.DispatcherTimer]::new()
$timer.Interval = [TimeSpan]::FromMilliseconds(3200)
$timer.Add_Tick({
  if (-not [bool]$script:Config["wander"]) {
    return
  }

  $dx = $script:Random.Next(-90, 91)
  $dy = $script:Random.Next(-60, 61)
  Move-Pet ($script:Window.Left + $dx) ($script:Window.Top + $dy) $true
})

$ddlTimer = [System.Windows.Threading.DispatcherTimer]::new()
$ddlTimer.Interval = [TimeSpan]::FromMinutes(1)
$ddlTimer.Add_Tick({
  Check-DdlReminders
})

Set-PetSize ([int]$script:Config["size"])
Set-PetImage ([string]$script:Config["imagePath"])

$workArea = [System.Windows.SystemParameters]::WorkArea
if ([double]$script:Config["x"] -eq 0 -and [double]$script:Config["y"] -eq 0) {
  Move-Pet ($workArea.Right - $script:Window.Width - 40) ($workArea.Bottom - $script:Window.Height - 40) $false
} else {
  Move-Pet ([double]$script:Config["x"]) ([double]$script:Config["y"]) $false
}

$script:Window.Add_Loaded({
  Create-TrayIcon
  $timer.Start()
  $ddlTimer.Start()
  Check-DdlReminders
  if (-not [string]$script:Config["imagePath"]) {
    Select-PetImage
  }
})

$script:Window.ShowDialog() | Out-Null
