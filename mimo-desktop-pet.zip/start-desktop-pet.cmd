@echo off
start "" powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0desktop-pet.ps1"
exit /b
